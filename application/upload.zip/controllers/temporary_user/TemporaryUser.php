<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class TemporaryUser extends Temporary_Student_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model("live_class_model");
        $this->load->model("temporary_admission_model");
        $this->load->library('form_validation');
    }

    public function index()
    {
        $this->load->view('temporarystudent/header');
        $this->load->view('temporarystudent/home');
        
    }
}
