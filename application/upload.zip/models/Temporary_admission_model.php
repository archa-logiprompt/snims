<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Temporary_admission_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->current_session = $this->setting_model->getCurrentSession();
    }

    public function create($data)
    {
        $this->db->insert('temporary_admission', $data);
    }

    public function checkUser($username, $otp)
    {

        $user_id = $this->db->select('id,phone')->where('user_id', $username)->get('temporary_admission')->row();
        $this->db->where('id', $user_id->id)->update('temporary_admission', ['otp' => $otp]);
        return $user_id;
    }

    public function checkOtp($id, $otp)
    {
        $user_data = $this->db->where('id', $id)->where('otp', $otp)->get('temporary_admission')->row();
        return ($user_data);
    }
}
